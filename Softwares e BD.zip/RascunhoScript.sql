use estoque;

select * from categoria;

select * from produto;



------
insert into categoria (id,nome) values ('0','Bebidas');
delete from produto where id= 2;
select nome='Coca cola',descricao='Coca cola 2,5 litros',preco_custo='7',preco_venda='9',quantidade='10',unidade_medida='lt',categoria_id='1' 
from produto 
WHERE id= '3'